<?php
if(empty($_POST['submit']))
{
echo "Form is not submitted!";
exit;
}
if(empty($_POST["myName"]) ||
empty($_POST["myEmail"]) ||
empty($_POST["myComments"}))
{
echo "Please fill the form";
exit;
}
$myName = $_POST["myName"];
$myEmail = $_POST["myEmail"];
$myComment = $_POST["myComments"];
mail( 'pmj@user10.com' , 'New form submission' , 
"New form submission: Name: $name, Email:$email", Body: $myComments );
header('Location: thank-you.html');
?>